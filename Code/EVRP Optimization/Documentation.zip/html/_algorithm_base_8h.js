var _algorithm_base_8h =
[
    [ "AlgorithmBase", "class_algorithm_base.html", "class_algorithm_base" ]
];
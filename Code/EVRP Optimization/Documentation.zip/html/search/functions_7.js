var searchData=
[
  ['neh_5fcalculation_0',['NEH_Calculation',['../class_n_e_h___nearest_neighbor.html#ac5e7990cabd81eec17a0a9b22610cacd',1,'NEH_NearestNeighbor']]],
  ['neh_5fnearestneighbor_1',['NEH_NearestNeighbor',['../class_n_e_h___nearest_neighbor.html#a48a5f696771be763a2a4f193e6957b00',1,'NEH_NearestNeighbor']]]
];

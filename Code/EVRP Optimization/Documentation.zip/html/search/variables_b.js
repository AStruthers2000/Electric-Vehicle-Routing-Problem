var searchData=
[
  ['name_0',['name',['../class_algorithm_base.html#aeb0e49023bbb319d7b46b8042fb9c0d6',1,'AlgorithmBase']]],
  ['nodes_1',['nodes',['../class_e_v_r_p___solver.html#aff3c1465c0fd932015c18ef081d7cb13',1,'EVRP_Solver::nodes'],['../_graph_structure_8h.html#aa06f172ac3f4b3ebef947ceb37e8d311',1,'EVRP_Data::nodes']]],
  ['num_5fgenerations_2',['NUM_GENERATIONS',['../_random_search_optimizer_8h.html#aab2742d3366233f20284e834ac5d0112',1,'RandomSearchOptimizer.h']]]
];

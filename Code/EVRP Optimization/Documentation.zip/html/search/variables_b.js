var searchData=
[
  ['vehiclebatterycapacity_0',['vehicleBatteryCapacity',['../class_e_v_r_p___solver.html#a6ff53467d3b98dd380efbe22f01e63c8',1,'EVRP_Solver']]],
  ['vehiclefuelconsumptionrate_1',['vehicleFuelConsumptionRate',['../class_e_v_r_p___solver.html#aedb94b94ee5df8a79dde027bb6848dac',1,'EVRP_Solver']]],
  ['vehicleloadcapacity_2',['vehicleLoadCapacity',['../class_e_v_r_p___solver.html#a65e7d028308be3a5e540c6e4256d57c4',1,'EVRP_Solver']]]
];

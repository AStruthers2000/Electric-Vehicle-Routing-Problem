var searchData=
[
  ['node_0',['Node',['../_graph_structure_8h.html#struct_node',1,'']]],
  ['nodes_1',['nodes',['../class_e_v_r_p___solver.html#a8f6b84784c9417d6239c1f7329116a6a',1,'EVRP_Solver::nodes'],['../_graph_structure_8h.html#acc8c7505937e58df795136f100694388',1,'EVRP_Data::nodes']]]
];

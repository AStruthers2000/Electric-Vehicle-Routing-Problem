var searchData=
[
  ['optimization_5fresult_0',['optimization_result',['../_graph_structure_8h.html#structoptimization__result',1,'']]]
];

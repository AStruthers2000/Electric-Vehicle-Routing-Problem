var searchData=
[
  ['batteryconsumptionrate_0',['batteryConsumptionRate',['../class_vehicle.html#a906b309f5878a0291fba44c4400507a5',1,'Vehicle']]],
  ['batterycost_1',['BatteryCost',['../class_vehicle.html#a14b9bebe6568fa6278256acd0cf9e45f',1,'Vehicle']]]
];

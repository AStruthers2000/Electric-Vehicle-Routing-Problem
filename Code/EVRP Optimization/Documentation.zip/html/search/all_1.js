var searchData=
[
  ['algorithm_5fname_0',['algorithm_name',['../_graph_structure_8h.html#abc4a7246e5c88dd1006d2af810127164',1,'optimization_result']]],
  ['algorithmbase_1',['algorithmbase',['../class_algorithm_base.html',1,'AlgorithmBase'],['../class_algorithm_base.html#a77303cd98d372fabb7d28d687c81859b',1,'AlgorithmBase::AlgorithmBase()'],['../class_algorithm_base.html#a37f6568763eca8c467a78c5034d2c8de',1,'AlgorithmBase::AlgorithmBase(const string &amp;algorithm_name, const EVRP_Data &amp;data)']]],
  ['algorithmbase_2ecpp_2',['AlgorithmBase.cpp',['../_algorithm_base_8cpp.html',1,'']]],
  ['algorithmbase_2eh_3',['AlgorithmBase.h',['../_algorithm_base_8h.html',1,'']]],
  ['astar_5fpathfinding_4',['astar_pathfinding',['../class_vehicle.html#af55c39a1050a18bbd760575c5ec0776f',1,'Vehicle']]]
];

var searchData=
[
  ['node_0',['Node',['../_graph_structure_8h.html#a3b09f37e675bcd48a01bf22155996872',1,'GraphStructure.h']]],
  ['node_5fdistances_1',['node_distances',['../class_n_e_h___nearest_neighbor.html#a4911930144907ce7a07db34fdc5ee8e1',1,'NEH_NearestNeighbor']]]
];

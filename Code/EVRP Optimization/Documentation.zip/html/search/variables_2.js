var searchData=
[
  ['currentbatterycapacity_0',['currentBatteryCapacity',['../class_vehicle.html#a143b8639c95b9ce5883c4b5679591025',1,'Vehicle']]],
  ['currentinventorycapacity_1',['currentInventoryCapacity',['../class_vehicle.html#a8a3aea9e147d7b4fcac4acc93a14d193',1,'Vehicle']]],
  ['customerstartindex_2',['customerStartIndex',['../_graph_structure_8h.html#a0d2cbe267f074354fec4678a7585c080',1,'EVRP_Data']]]
];

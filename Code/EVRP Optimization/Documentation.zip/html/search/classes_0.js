var searchData=
[
  ['algorithmbase_0',['AlgorithmBase',['../class_algorithm_base.html',1,'']]]
];

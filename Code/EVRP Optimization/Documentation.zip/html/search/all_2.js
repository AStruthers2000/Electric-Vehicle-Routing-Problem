var searchData=
[
  ['batteryconsumptionrate_0',['batteryConsumptionRate',['../class_vehicle.html#a906b309f5878a0291fba44c4400507a5',1,'Vehicle']]],
  ['batterycost_1',['BatteryCost',['../class_vehicle.html#ad959c1880a3dd721721f23f8fccae9b8',1,'Vehicle']]]
];

var searchData=
[
  ['data_0',['data',['../class_e_v_r_p___solver.html#a18e8f34b6a7f2cf94cd1b70734838ada',1,'EVRP_Solver']]],
  ['demand_1',['demand',['../_graph_structure_8h.html#a743d222e005f1160358a82d9329e5191',1,'Node']]],
  ['description_2',['Project Description',['../index.html#proj_description',1,'']]]
];

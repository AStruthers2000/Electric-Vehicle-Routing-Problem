var searchData=
[
  ['hyper_5fparameters_0',['hyper_parameters',['../class_algorithm_base.html#ad9d01d6a7dbba7aeb833df5d3e9e2127',1,'AlgorithmBase']]],
  ['hyperparameters_1',['hyperparameters',['../_graph_structure_8h.html#a08144b4d8a645a5fa974078f9d932824',1,'optimization_result']]]
];

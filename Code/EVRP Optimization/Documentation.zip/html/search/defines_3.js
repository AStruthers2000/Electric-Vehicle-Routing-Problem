var searchData=
[
  ['verbose_0',['VERBOSE',['../_e_v_r_p___solver_8h.html#a42f8c497a1968074f38bf5055c650dca',1,'EVRP_Solver.h']]]
];

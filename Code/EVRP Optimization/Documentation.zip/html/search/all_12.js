var searchData=
[
  ['where_20to_20start_0',['Where to Start',['../index.html#start',1,'']]]
];

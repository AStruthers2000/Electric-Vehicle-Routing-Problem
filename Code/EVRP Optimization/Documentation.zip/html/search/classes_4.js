var searchData=
[
  ['neh_5fnearestneighbor_0',['NEH_NearestNeighbor',['../class_n_e_h___nearest_neighbor.html',1,'']]],
  ['node_1',['Node',['../struct_node.html',1,'']]],
  ['node_5fdistances_2',['node_distances',['../class_n_e_h___nearest_neighbor.html#struct_n_e_h___nearest_neighbor_1_1node__distances',1,'NEH_NearestNeighbor']]]
];

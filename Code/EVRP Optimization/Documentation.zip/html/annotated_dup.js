var annotated_dup =
[
    [ "EVRP_Data", "_graph_structure_8h.html#struct_e_v_r_p___data", "_graph_structure_8h_struct_e_v_r_p___data" ],
    [ "EVRP_Solver", "class_e_v_r_p___solver.html", "class_e_v_r_p___solver" ],
    [ "GeneticAlgorithmOptimizer", "class_genetic_algorithm_optimizer.html", "class_genetic_algorithm_optimizer" ],
    [ "Node", "_graph_structure_8h.html#struct_node", "_graph_structure_8h_struct_node" ],
    [ "Vehicle", "class_vehicle.html", "class_vehicle" ]
];
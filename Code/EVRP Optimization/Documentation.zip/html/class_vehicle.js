var class_vehicle =
[
    [ "Vehicle", "class_vehicle.html#a4d8cde3af3de66c1429298cd6fc56049", null ],
    [ "BatteryCost", "class_vehicle.html#a14b9bebe6568fa6278256acd0cf9e45f", null ],
    [ "CalculateFullRouteDistance", "class_vehicle.html#a67f194a1a654e817e341bb520d13440b", null ],
    [ "CalculateInterNodeDistance", "class_vehicle.html#a755c670d9bb9df9b16060068f646bf75", null ],
    [ "CanGetToNextCustomerSafely", "class_vehicle.html#abf43595f849e157719c2c72a9f1106d4", null ],
    [ "GetClosestChargingStationToNode", "class_vehicle.html#a3daa285905cfde5bb3094b4b97fd2df6", null ],
    [ "ResetVehicle", "class_vehicle.html#a607c91addcd827e4bb2d9f1845577a8b", null ],
    [ "SimulateDrive", "class_vehicle.html#a745391430123365c9ea17cbc8a2981d5", null ],
    [ "_battery", "class_vehicle.html#af0986d6c84121c5464151535a956738f", null ],
    [ "_batteryRate", "class_vehicle.html#adad9d2542e8c987e49619cd28267818d", null ],
    [ "_inventory", "class_vehicle.html#ac42621a06d5f9369c2db504b44491282", null ],
    [ "_nodes", "class_vehicle.html#a900bd84fd2c122a2f0fc4f235aa971d0", null ],
    [ "batteryConsumptionRate", "class_vehicle.html#a906b309f5878a0291fba44c4400507a5", null ],
    [ "currentBatteryCapacity", "class_vehicle.html#a143b8639c95b9ce5883c4b5679591025", null ],
    [ "currentInventoryCapacity", "class_vehicle.html#a8a3aea9e147d7b4fcac4acc93a14d193", null ],
    [ "maxBatteryCapacity", "class_vehicle.html#ae8ad9fbb164f5beb4ef78e2c8676c7f7", null ],
    [ "maxInventoryCapacity", "class_vehicle.html#a47217c8bd98a16bf7aec3328d8f5a2d5", null ]
];
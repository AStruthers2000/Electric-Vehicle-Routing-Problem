var _n_e_h___nearest_neighbor_8h =
[
    [ "NEH_NearestNeighbor", "class_n_e_h___nearest_neighbor.html", "class_n_e_h___nearest_neighbor" ],
    [ "NEH_NearestNeighbor::node_distances", "class_n_e_h___nearest_neighbor.html#struct_n_e_h___nearest_neighbor_1_1node__distances", [
      [ "distance_map", "class_n_e_h___nearest_neighbor.html#a2cf31df450ececdd798c2135be8447ec", null ],
      [ "me", "class_n_e_h___nearest_neighbor.html#ac7263d295f322dbdd471e6d73e0c5de7", null ]
    ] ]
];
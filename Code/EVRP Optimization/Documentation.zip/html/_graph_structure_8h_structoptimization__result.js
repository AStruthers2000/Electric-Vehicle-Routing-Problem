var _graph_structure_8h_structoptimization__result =
[
    [ "algorithm_name", "_graph_structure_8h.html#abc4a7246e5c88dd1006d2af810127164", null ],
    [ "distance", "_graph_structure_8h.html#acff691e26c8e577bde5466f1b21f3f64", null ],
    [ "execution_time", "_graph_structure_8h.html#ac9d3e68ebe8e32698bcb86d96df1012b", null ],
    [ "hyperparameters", "_graph_structure_8h.html#a08144b4d8a645a5fa974078f9d932824", null ],
    [ "solution_decoded", "_graph_structure_8h.html#a99959cd4d3bf4ec4373a781faaa77d42", null ],
    [ "solution_encoded", "_graph_structure_8h.html#a7d7b6878012c4417f2d20572c6105d2a", null ]
];
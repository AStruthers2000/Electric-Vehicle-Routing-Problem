var _graph_structure_8h_struct_e_v_r_p___data =
[
    [ "customerStartIndex", "_graph_structure_8h.html#a0d2cbe267f074354fec4678a7585c080", null ],
    [ "fuelCapacity", "_graph_structure_8h.html#ae0477139e4f9183e510c1dcaed678d52", null ],
    [ "fuelConsumptionRate", "_graph_structure_8h.html#a3247aec6a1df0649f885203e76ec9e9b", null ],
    [ "loadCapacity", "_graph_structure_8h.html#ab01f753d693662a727c4ee4883562ab5", null ],
    [ "nodes", "_graph_structure_8h.html#acc8c7505937e58df795136f100694388", null ]
];
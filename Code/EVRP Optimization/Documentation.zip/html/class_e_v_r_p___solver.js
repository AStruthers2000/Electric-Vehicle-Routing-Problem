var class_e_v_r_p___solver =
[
    [ "EVRP_Solver", "class_e_v_r_p___solver.html#a442446246c42989318c3fe87ed8779cc", null ],
    [ "SolveEVRP", "class_e_v_r_p___solver.html#a0ee9e04046364183b3ba80e8d073a7cd", null ],
    [ "data", "class_e_v_r_p___solver.html#a18e8f34b6a7f2cf94cd1b70734838ada", null ],
    [ "nodes", "class_e_v_r_p___solver.html#a8f6b84784c9417d6239c1f7329116a6a", null ],
    [ "vehicleBatteryCapacity", "class_e_v_r_p___solver.html#a6ff53467d3b98dd380efbe22f01e63c8", null ],
    [ "vehicleFuelConsumptionRate", "class_e_v_r_p___solver.html#aedb94b94ee5df8a79dde027bb6848dac", null ],
    [ "vehicleLoadCapacity", "class_e_v_r_p___solver.html#a65e7d028308be3a5e540c6e4256d57c4", null ]
];
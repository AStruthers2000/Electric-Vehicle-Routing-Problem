var _graph_structure_8h_struct_e_v_r_p___problem =
[
    [ "customerStartIndex", "_graph_structure_8h.html#ace07355ff0a49725328c8bc393f20f3c", null ],
    [ "nodes", "_graph_structure_8h.html#aa2678520d617c5cb783c9e549c886021", null ],
    [ "truck", "_graph_structure_8h.html#a41c6231c5224cfaf63336f7ffa6c1e67", null ]
];
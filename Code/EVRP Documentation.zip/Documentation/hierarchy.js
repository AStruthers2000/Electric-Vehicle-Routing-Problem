var hierarchy =
[
    [ "AlgorithmBase", "class_algorithm_base.html", [
      [ "GeneticAlgorithmOptimizer", "class_genetic_algorithm_optimizer.html", null ],
      [ "NEH_NearestNeighbor", "class_n_e_h___nearest_neighbor.html", null ],
      [ "RandomSearchOptimizer", "class_random_search_optimizer.html", null ]
    ] ],
    [ "EVRP_Data", "_graph_structure_8h.html#struct_e_v_r_p___data", null ],
    [ "EVRP_Solver", "class_e_v_r_p___solver.html", null ],
    [ "HelperFunctions", "class_helper_functions.html", null ],
    [ "Node", "struct_node.html", null ],
    [ "NEH_NearestNeighbor::node_distances", "class_n_e_h___nearest_neighbor.html#struct_n_e_h___nearest_neighbor_1_1node__distances", null ],
    [ "optimization_result", "_graph_structure_8h.html#structoptimization__result", null ],
    [ "Vehicle", "class_vehicle.html", null ]
];
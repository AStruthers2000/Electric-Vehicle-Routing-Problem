var annotated_dup =
[
    [ "AlgorithmBase", "class_algorithm_base.html", "class_algorithm_base" ],
    [ "EVRP_Data", "_graph_structure_8h.html#struct_e_v_r_p___data", "_graph_structure_8h_struct_e_v_r_p___data" ],
    [ "EVRP_Solver", "class_e_v_r_p___solver.html", "class_e_v_r_p___solver" ],
    [ "GeneticAlgorithmOptimizer", "class_genetic_algorithm_optimizer.html", "class_genetic_algorithm_optimizer" ],
    [ "HelperFunctions", "class_helper_functions.html", "class_helper_functions" ],
    [ "NEH_NearestNeighbor", "class_n_e_h___nearest_neighbor.html", "class_n_e_h___nearest_neighbor" ],
    [ "Node", "struct_node.html", "struct_node" ],
    [ "optimization_result", "_graph_structure_8h.html#structoptimization__result", "_graph_structure_8h_structoptimization__result" ],
    [ "RandomSearchOptimizer", "class_random_search_optimizer.html", "class_random_search_optimizer" ],
    [ "Vehicle", "class_vehicle.html", "class_vehicle" ]
];
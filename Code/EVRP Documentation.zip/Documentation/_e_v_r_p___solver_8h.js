var _e_v_r_p___solver_8h =
[
    [ "EVRP_Solver", "class_e_v_r_p___solver.html", "class_e_v_r_p___solver" ],
    [ "DATA_PATH", "_e_v_r_p___solver_8h.html#aeaea0d7f4e323d179d9eb059557b5b7b", null ],
    [ "READ_FILENAME", "_e_v_r_p___solver_8h.html#a846a6f3ddbedec08a461cbdd2277d9c8", null ],
    [ "WRITE_FILENAME", "_e_v_r_p___solver_8h.html#a45c52aa47845718441bf59604d6e1082", null ]
];
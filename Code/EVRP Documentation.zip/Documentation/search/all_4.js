var searchData=
[
  ['data_0',['data',['../class_e_v_r_p___solver.html#a18e8f34b6a7f2cf94cd1b70734838ada',1,'EVRP_Solver']]],
  ['data_5fpath_1',['DATA_PATH',['../_e_v_r_p___solver_8h.html#aeaea0d7f4e323d179d9eb059557b5b7b',1,'EVRP_Solver.h']]],
  ['demand_2',['demand',['../struct_node.html#a743d222e005f1160358a82d9329e5191',1,'Node']]],
  ['description_3',['Project Description',['../index.html#proj_description',1,'']]],
  ['distance_4',['distance',['../_graph_structure_8h.html#acff691e26c8e577bde5466f1b21f3f64',1,'optimization_result']]],
  ['distance_5fmap_5',['distance_map',['../class_n_e_h___nearest_neighbor.html#a2cf31df450ececdd798c2135be8447ec',1,'NEH_NearestNeighbor::node_distances']]]
];

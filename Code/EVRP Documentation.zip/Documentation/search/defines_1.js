var searchData=
[
  ['old_5fnot_5foptimized_0',['OLD_NOT_OPTIMIZED',['../_e_v_r_p___solver_8h.html#a3755f2d18a314e4b286349cb5c295ff6',1,'EVRP_Solver.h']]]
];

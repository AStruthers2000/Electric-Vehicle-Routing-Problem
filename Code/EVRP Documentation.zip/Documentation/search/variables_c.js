var searchData=
[
  ['population_5fsize_0',['POPULATION_SIZE',['../_genetic_algorithm_optimizer_8h.html#a7ff1b7b64b7f27a97bedfc47248eaa30',1,'GeneticAlgorithmOptimizer.h']]],
  ['problem_5fdata_1',['problem_data',['../class_algorithm_base.html#ad83df42564aa8a94f169ab78b4625731',1,'AlgorithmBase']]]
];

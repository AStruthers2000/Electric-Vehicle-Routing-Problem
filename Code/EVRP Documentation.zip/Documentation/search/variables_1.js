var searchData=
[
  ['algorithm_5fname_0',['algorithm_name',['../_graph_structure_8h.html#abc4a7246e5c88dd1006d2af810127164',1,'optimization_result']]]
];

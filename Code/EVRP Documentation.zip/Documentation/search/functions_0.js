var searchData=
[
  ['algorithmbase_0',['algorithmbase',['../class_algorithm_base.html#a77303cd98d372fabb7d28d687c81859b',1,'AlgorithmBase::AlgorithmBase()'],['../class_algorithm_base.html#a37f6568763eca8c467a78c5034d2c8de',1,'AlgorithmBase::AlgorithmBase(const string &amp;algorithm_name, const EVRP_Data &amp;data)']]],
  ['astar_5fpathfinding_1',['astar_pathfinding',['../class_vehicle.html#af55c39a1050a18bbd760575c5ec0776f',1,'Vehicle']]]
];

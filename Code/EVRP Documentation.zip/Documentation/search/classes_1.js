var searchData=
[
  ['evrp_5fdata_0',['EVRP_Data',['../_graph_structure_8h.html#struct_e_v_r_p___data',1,'']]],
  ['evrp_5fsolver_1',['EVRP_Solver',['../class_e_v_r_p___solver.html',1,'']]]
];

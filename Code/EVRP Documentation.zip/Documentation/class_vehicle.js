var class_vehicle =
[
    [ "Vehicle", "class_vehicle.html#a35beeb0d09747f525dcdada734c663b7", null ],
    [ "astar_pathfinding", "class_vehicle.html#af55c39a1050a18bbd760575c5ec0776f", null ],
    [ "BatteryCost", "class_vehicle.html#ad959c1880a3dd721721f23f8fccae9b8", null ],
    [ "CalculateFullRouteDistance", "class_vehicle.html#a73b4982d4f65292c2ade0a48f54bbc8d", null ],
    [ "CanGetToNextCustomerSafely", "class_vehicle.html#a8df6aeefe4f2a71127f9ed7f2de635e9", null ],
    [ "GetClosestChargingStationToNode", "class_vehicle.html#a2ae6d57f8ed49142bba3395600dc29d2", null ],
    [ "ResetVehicle", "class_vehicle.html#a607c91addcd827e4bb2d9f1845577a8b", null ],
    [ "SimulateDrive", "class_vehicle.html#a9e45048058f35d303d2c17ea1f7e657d", null ],
    [ "_battery", "class_vehicle.html#af0986d6c84121c5464151535a956738f", null ],
    [ "_batteryRate", "class_vehicle.html#adad9d2542e8c987e49619cd28267818d", null ],
    [ "_inventory", "class_vehicle.html#ac42621a06d5f9369c2db504b44491282", null ],
    [ "_nodes", "class_vehicle.html#ae7f838c1bd9a8852060f92103d774a81", null ],
    [ "batteryConsumptionRate", "class_vehicle.html#a906b309f5878a0291fba44c4400507a5", null ],
    [ "currentBatteryCapacity", "class_vehicle.html#a143b8639c95b9ce5883c4b5679591025", null ],
    [ "currentInventoryCapacity", "class_vehicle.html#a8a3aea9e147d7b4fcac4acc93a14d193", null ],
    [ "maxBatteryCapacity", "class_vehicle.html#ae8ad9fbb164f5beb4ef78e2c8676c7f7", null ],
    [ "maxInventoryCapacity", "class_vehicle.html#a47217c8bd98a16bf7aec3328d8f5a2d5", null ]
];
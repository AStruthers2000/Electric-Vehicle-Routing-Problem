var _data_analysis_8py =
[
    [ "raw_row", "_data_analysis_8py.html#a56803aaaf5259de4948864c62c5fc653", null ]
];
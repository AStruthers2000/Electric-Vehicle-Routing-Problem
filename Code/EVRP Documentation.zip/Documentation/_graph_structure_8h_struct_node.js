var _graph_structure_8h_struct_node =
[
    [ "demand", "_graph_structure_8h.html#a743d222e005f1160358a82d9329e5191", null ],
    [ "index", "_graph_structure_8h.html#ac8055cdbda20cacce417192557741ab8", null ],
    [ "isCharger", "_graph_structure_8h.html#afecbae2c7205de41b07f6328bcc58704", null ],
    [ "x", "_graph_structure_8h.html#a1082fca4b71cc3cc02d78c35108f9059", null ],
    [ "y", "_graph_structure_8h.html#a441d3c5ba86597f4c391408d9fe6d242", null ]
];
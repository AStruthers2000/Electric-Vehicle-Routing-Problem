var class_algorithm_base =
[
    [ "AlgorithmBase", "class_algorithm_base.html#a77303cd98d372fabb7d28d687c81859b", null ],
    [ "AlgorithmBase", "class_algorithm_base.html#a37f6568763eca8c467a78c5034d2c8de", null ],
    [ "~AlgorithmBase", "class_algorithm_base.html#a01862a2fa8e29b154e6d95c1287a598e", null ],
    [ "GetHyperParameters", "class_algorithm_base.html#a91bfaeeb0d423d73f4ec9b87ffbf1c08", null ],
    [ "GetName", "class_algorithm_base.html#aa5b1731329fc03bb93d011594b972573", null ],
    [ "Optimize", "class_algorithm_base.html#a7914567a99ecc52383e01fda80ef9aad", null ],
    [ "PrintIfTheTimeIsRight", "class_algorithm_base.html#aea675ca00b3e47afe75b413195a16ca0", null ],
    [ "SetHyperParameters", "class_algorithm_base.html#a095b80e35fcf63e5f623730772f9f826", null ],
    [ "hyper_parameters", "class_algorithm_base.html#ad9d01d6a7dbba7aeb833df5d3e9e2127", null ],
    [ "name", "class_algorithm_base.html#aeb0e49023bbb319d7b46b8042fb9c0d6", null ],
    [ "problem_data", "class_algorithm_base.html#ad83df42564aa8a94f169ab78b4625731", null ],
    [ "vehicle", "class_algorithm_base.html#a0f24e23a948de9928cac6fa78422e292", null ]
];